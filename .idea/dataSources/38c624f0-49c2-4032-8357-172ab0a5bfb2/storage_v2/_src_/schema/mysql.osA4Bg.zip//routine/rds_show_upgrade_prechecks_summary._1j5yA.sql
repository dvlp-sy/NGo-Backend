create
    definer = rdsadmin@localhost procedure rds_show_upgrade_prechecks_summary()
BEGIN
    DECLARE v_called_by_user VARCHAR(50);
    DECLARE v_engine_version VARCHAR(50);
    DECLARE sql_logging BOOLEAN;
    SELECT @@sql_log_bin INTO sql_logging;

    BEGIN
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
                BEGIN
                    SET @@sql_log_bin=sql_logging;
                    RESIGNAL;
                END;
        SET @@sql_log_bin=OFF;

        SELECT user() INTO v_called_by_user;
        SELECT version() INTO v_engine_version;

        
        INSERT INTO mysql.rds_history(called_by_user, action, mysql_version) VALUES (v_called_by_user, 'prechecks summary', v_engine_version);
        COMMIT;
        SELECT summary from mysql.rds_upgrade_prechecks ORDER BY start_timestamp DESC LIMIT 1;
        
        INSERT INTO mysql.rds_history(called_by_user, action, mysql_version) VALUES (v_called_by_user, 'prechecks summary:ok', v_engine_version);
        COMMIT;

        SET @@sql_log_bin=sql_logging;

    END;

END;

