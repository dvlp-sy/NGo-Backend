create
    definer = rdsadmin@localhost procedure rds_start_upgrade_prechecks(IN targetEngineName varchar(50), IN targetEngineVersion varchar(50))
BEGIN
    DECLARE v_engine_version VARCHAR(50);
    DECLARE v_called_by_user VARCHAR(50);
    DECLARE most_recent_action VARCHAR(20);
    DECLARE most_recent_status VARCHAR(50);
    DECLARE sql_logging BOOLEAN;
    SELECT @@sql_log_bin INTO sql_logging;

    BEGIN
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
                BEGIN
                    SET @@sql_log_bin=sql_logging;
                    RESIGNAL;
                END;
        SET @@sql_log_bin=OFF;
        SELECT user() INTO v_called_by_user;
        SELECT version() INTO v_engine_version;
        
        INSERT INTO mysql.rds_history(called_by_user, action, mysql_version) VALUES (v_called_by_user, 'start prechecks', v_engine_version);
        COMMIT;
        SELECT action INTO most_recent_action FROM mysql.rds_upgrade_prechecks ORDER BY start_timestamp DESC LIMIT 1;
        SELECT status INTO most_recent_status FROM mysql.rds_upgrade_prechecks ORDER BY start_timestamp DESC LIMIT 1;

        
        IF targetEngineName <> 'mysql' THEN
           SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only mysql target engine is supported';
        END IF;

        
        IF targetEngineVersion IS NULL OR targetEngineVersion = '' THEN
           SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Target engine version is required';

        
        ELSEIF NOT targetEngineVersion REGEXP '^[0-9]+(\.[0-9]+){2}$' THEN
               SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Target engine version must be in X.X.X format';
        END IF;

        IF most_recent_action = 'engine upgrade' AND most_recent_status IN ('in progress') THEN
           SIGNAL SQLSTATE '45002' SET MESSAGE_TEXT = 'Cannot call procedure while engine upgrade in progress.';
        ELSEIF most_recent_action = 'precheck' AND most_recent_status IN ('pending', 'in progress') THEN
           SIGNAL SQLSTATE '45002'
               SET MESSAGE_TEXT = 'Upgrade prechecks in progress. Please stop currently running prechecks using mysql.rds_stop_upgrade_prechecks()';
        ELSE
           INSERT INTO mysql.rds_upgrade_prechecks(action,status,engine_version,target_engine_name,target_engine_version) VALUES ('precheck','pending',v_engine_version,targetEngineName,targetEngineVersion);
           
           INSERT INTO mysql.rds_history(called_by_user, action, mysql_version) VALUES (v_called_by_user, 'start prechecks:ok', v_engine_version);
           COMMIT;
           SELECT 'Starting upgrade prechecks.' as 'Success';
        END IF;

        SET @@sql_log_bin=sql_logging;
    END;

END;

